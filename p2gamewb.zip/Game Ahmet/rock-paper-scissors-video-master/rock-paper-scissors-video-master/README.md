uitleg over wat het is

Steen, papier, schaar is een eenvoudig handspel dat vaak wordt gespeeld om willekeurige beslissingen te nemen of gewoon voor de lol. Het spel heeft drie mogelijke zetten: steen, papier en schaar. Elke zet verslaat één andere zet en wordt verslagen door de derde.

Hier zijn de basiselementen van het spel:

Steen: Wint van schaar, maar verliest van papier.
Papier: Wint van steen, maar verliest van schaar.
Schaar: Wint van papier, maar verliest van steen.

Wat is het doel

Het doel van het spel is om te raden welke zet je tegenstander zal maken, en vervolgens een zet te kiezen die zijn of haar zet verslaat. Als beide spelers dezelfde zet kiezen, is het meestal een gelijkspel en wordt het spel vaak opnieuw gespeeld.

Hier is een eenvoudig voorbeeld:

Speler A kiest steen.
Speler B kiest schaar.
In dit geval wint speler A omdat steen schaar verslaat. Het doel is dus om de juiste zet te kiezen op basis van wat je denkt dat je tegenstander zal kiezen. Het spel is vaak snel en leuk, en er zijn zelfs toernooien en competities voor steen, papier, schaar.
