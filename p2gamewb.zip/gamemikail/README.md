Game Mikail
Cross adventure is een meeslepende en leuke game waarin je vaardigheden en reactietijd worden getest terwijl je een opwindend avontuur beleeft. Het doel van het spel is om een personage veilig over een drukke weg, een bruisende rivier en andere uitdagende obstakels te leiden.
Hoe te spelen:
Beweging:
Gebruik de pijltjestoetsen op je toetsenbord om je personage in verschillende richtingen te verplaatsen.
Ontwijk obstakels:
Wees voorzichtig en ontwijk voertuigen op de weg, spring over drijvende objecten in de rivier en vermijd andere obstakels die je pad kruisen.
Verzamel punten:
Hoe verder je komt, hoe meer punten je kunt scoren.
Overleef zo lang mogelijk:
Het doel is om zo ver mogelijk te komen zonder te worden geraakt of in het water te vallen. Test je vaardigheden en probeer je eigen record te verbreken.